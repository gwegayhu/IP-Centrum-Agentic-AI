import os
import json
from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	ScrapeWebsiteTool,
	FileReadTool,
	JinaScrapeWebsiteTool
)


from pydantic import BaseModel
from jambo import SchemaConverter


@CrewBase
class IpCentrumPhase1IntelligenceFoundationCrew:
    """IpCentrumPhase1IntelligenceFoundation crew"""

    
    @agent
    def patent_document_intelligence_analyst(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["patent_document_intelligence_analyst"],
            
            
            tools=[				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def patent_case_risk_monitor(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["patent_case_risk_monitor"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def european_patent_regulatory_intelligence_specialist(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["european_patent_regulatory_intelligence_specialist"],
            
            
            tools=[				ScrapeWebsiteTool(),
				JinaScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def patent_case_data_quality_controller(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["patent_case_data_quality_controller"],
            
            
            tools=[				ScrapeWebsiteTool(),
				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    

    
    @task
    def patent_document_analysis(self) -> Task:
        return Task(
            config=self.tasks_config["patent_document_analysis"],
            markdown=True,
            output_json=self._load_response_format("patent_document_analysis"),
            
        )
    
    @task
    def data_quality_verification(self) -> Task:
        return Task(
            config=self.tasks_config["data_quality_verification"],
            markdown=False,
            
            
        )
    
    @task
    def case_risk_assessment(self) -> Task:
        return Task(
            config=self.tasks_config["case_risk_assessment"],
            markdown=False,
            
            
        )
    
    @task
    def regulatory_intelligence_monitoring(self) -> Task:
        return Task(
            config=self.tasks_config["regulatory_intelligence_monitoring"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the IpCentrumPhase1IntelligenceFoundation crew"""

        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,

            chat_llm=LLM(model="openai/gpt-4o-mini"),
        )


    def _load_response_format(self, name):
        with open(os.path.join(self.base_directory, "config", f"{name}.json")) as f:
            json_schema = json.loads(f.read())

        return SchemaConverter.build(json_schema)

